const API_BASE_URL = "https://team-env.eba-mghaptds.ap-south-1.elasticbeanstalk.com"; // 🔹 Replace with your backend URL

// ✅ Register new user
export const registerUser = async (name, email, password) => {
  const response = await fetch(`${API_BASE_URL}/api/ath/sgnp`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name, email, password }),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Registration failed");
  }

  return response.json();
};

// ✅ Login user (for your Login.jsx)
export const loginUser = async (email, password) => {
  const response = await fetch(`${API_BASE_URL}/api/ath/lgn`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Login failed");
  }

  const data = await response.json();
  localStorage.setItem("token", data.token); // Save JWT
  return data;
};
