// import React from 'react'
// import Home from './pages/Home/Home'
// import Login from './pages/Login/Login'
// import CreateAcc from './pages/CreateAcc/CreateAcc'
// import Forgot from '../src/pages/Forgot/Forgot'
// import {BrowserRouter, Routes, Route} from 'react-router-dom'
// import Dashboard from './pages/Dashboard/Dashboard'
// import SupportPage from './pages/SupportPage/SupportPage'
// import KnowledgeManagement from './pages/KnowledgeManagement/KnowledgeManagement';


// const App = () => {
//   return (
//     <div>
    
//       <Routes>
//         {/* <Route path="/" element={<Home/>}></Route>
//         <Route path="/login" element={<Login/>}></Route>
//         <Route path="/CreateAcc" element={<CreateAcc/>}></Route>
//         <Route path="/Forgot" element = {<Forgot/>}></Route> */}
//         {/* <Route path="/Dashboard" element={<Dashboard></Dashboard>}></Route> */}
//       </Routes>
//         {/* <Dashboard/> */}
//         <SupportPage/>
//         <KnowledgeManagement/>
//     </div>
//   )
// }

// export default App



import React, { useState } from 'react';
// import Home from './pages/Home/Home'
// import Login from './pages/Login/Login'
// import CreateAcc from './pages/CreateAcc/CreateAcc'
// import Forgot from '../src/pages/Forgot/Forgot'
import {BrowserRouter, Routes, Route} from 'react-router-dom'
// import Dashboard from './pages/Dashboard/Dashboard'
// import SupportPage from './pages/SupportPage/SupportPage';
// import KnowledgeManagement2 from './pages/KnowledgeManagement2/KnowledgeManagement2';
// import SupportPage1 from './pages/SupportPage1/SupportPage1';
// import KnowledgeManagement from './pages/KnowledgeManagement/KnowledgeManagement';
// import UsersPage from './pages/UsersPage/UsersPage';
// import Sidebar3 from './components/Sidebar3/Sidebar3';
// import SupportPage3 from './pages/SupportPage3/Supportpage3';
// import KnowledgeManagement3 from './pages/KnowledgeManagement3/KnowledgeManagement3';
import Admin from './pages/Admin/Admin';
import Agent from './pages/Agent/Agent';
import User from './pages/User/User';
const App = () => {
  // const [activePage, setActivePage] = useState('tickets'); // default tab
const [activePage, setActivePage] = useState('tickets');
  return (

    //  <div className="app-layout">
    //   <Sidebar3 activeTab={activePage} setActiveTab={setActivePage} />

    <div>  
      
    <Routes>
         {/* <Route path="/" element={<Home/>}></Route>
   <Route path="/login" element={<Login/>}></Route>
         <Route path="/CreateAcc" element={<CreateAcc/>}></Route>
         <Route path="/Forgot" element = {<Forgot/>}></Route> */}
         {/* <Route path="/Dashboard" element={<Dashboard></Dashboard>}></Route> */}
       </Routes>
         {/* <Dashboard/> */}
{/*          <SupportPage/>
         <KnowledgeManagement/> */}
    

      {/*Supprt Page*/}
      {/* Pass setActivePage to Sidebar through each page */}
      {activePage === 'tickets' && (
        <SupportPage activePage={activePage} setActivePage={setActivePage} />
      )}
      {activePage === 'knowledge' && (
        <KnowledgeManagement2 activePage={activePage} setActivePage={setActivePage} />
      )}




        {/* Adminpage */}
      {/* {activePage === 'tickets' && (
        <SupportPage1 activeTab={activePage} setActivePage={setActivePage} />
      )}

       {activePage === 'users' && (
          <UsersPage activeTab={activePage} setActiveTab={setActivePage} />
        )}


      {activePage === 'knowledge' && (
        <KnowledgeManagement activeTab={activePage} setActivePage={setActivePage} />
      )} */}

      {/* <UsersPage/> */}


      {/* <SupportPage3/> */}
      {/* <KnowledgeManagement3/> */}
          {/*User Page */}
      {/* {activePage === 'tickets' && (
        <SupportPage3 activePage={activePage} setActivePage={setActivePage} />
      )}
      {activePage === 'knowledge' && (
        <KnowledgeManagement3 activePage={activePage} setActivePage={setActivePage} />
      )} */}




{/* <Admin/> */}

<Agent/> 

{/* <User/> */}
    </div>
    // </div>
  );
};

export default App;
