import React from 'react';
import './Sidebar3.css';

const Sidebar3 = ({ activeTab, setActiveTab }) => {
  return (
    <div className="sidebar">
      <h1 className="logo">Admin</h1>
      <ul>
        <li
          className={activeTab === 'tickets' ? 'active' : ''}
          onClick={() => setActiveTab('tickets')}
        >
          Tickets
        </li>

        <li
          className={activeTab === 'users' ? 'active' : ''}
          onClick={() => setActiveTab('users')}
        >
          Users
        </li>

        <li
          className={activeTab === 'knowledge' ? 'active' : ''}
          onClick={() => setActiveTab('knowledge')}
        >
          Knowledge Base
        </li>
      </ul>
    </div>
  );
};

export default Sidebar3;
