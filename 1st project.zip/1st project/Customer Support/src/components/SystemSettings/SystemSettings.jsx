

// const SystemSettings = () => {
//   const [systemName, setSystemName] = useState("System Name");
//   const [emailConfig, setEmailConfig] = useState(true);

//   return (
//     <div className="system-settings">
//       <h3>System Settings</h3>
//       <div className="setting">
//         <label>System Name:</label>
//         <input 
//           value={systemName}
//           onChange={(e) => setSystemName(e.target.value)}
//         />
//       </div>
//       <div className="setting">
//         <label>Email Configuration:</label>
//         <input 
//           type="checkbox"
//           checked={emailConfig}
//           onChange={() => setEmailConfig(!emailConfig)}
//         />
//       </div>
//     </div>
//   );
// };

// export default SystemSettings;
import React, { useState } from 'react';
import './SystemSettings.css';

const SystemSettings = () => {
  const [settings, setSettings] = useState({
    systemName: true,
    emailConfig: true,
    emailIntegration: true,
  });

  const toggleSetting = (key) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="system-settings">
      <h2 className="settings-title">System Settings</h2>
      
      <div className="settings-section">
        <h3 className="settings-subtitle">General Settings</h3>
        
        <div className="setting-item">
          <span>System Name</span>
          <label className="toggle">
            <input
              type="checkbox"
              checked={settings.systemName}
              onChange={() => toggleSetting('systemName')}
            />
            <span className="toggle-slider"></span>
          </label>
        </div>
        
        <div className="dropdown">
          <select>
            <option>System Name</option>
          </select>
        </div>
        
        <div className="setting-item">
          <span>Email Configuration</span>
          <label className="toggle">
            <input
              type="checkbox"
              checked={settings.emailConfig}
              onChange={() => toggleSetting('emailConfig')}
            />
            <span className="toggle-slider"></span>
          </label>
        </div>
      </div>
      
      <div className="settings-section">
        <h3 className="settings-subtitle">Interrations</h3>
        
        <div className="setting-item">
          <div>
            <div>Email Configuration</div>
            <div className="setting-subtitle">meitred Suoont</div>
          </div>
          <div className="status-indicator active"></div>
        </div>
        
        <div className="dropdown">
          <select>
            <option>System Name</option>
          </select>
        </div>
        
        <div className="dropdown">
          <select>
            <option>Nimit torix</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default SystemSettings;