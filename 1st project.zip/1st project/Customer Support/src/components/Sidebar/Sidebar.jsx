// // src/components/Sidebar/Sidebar.jsx
// import React from "react";
// import { NavLink } from "react-router-dom";
// import "./Sidebar.css";

// const Sidebar = () => {
//   return (
//     <div className="sidebar">
//       <h2 className="logo">Dashboard</h2>
//       <ul>
//         <li>
//           <NavLink 
//             to="/" 
//             className={({ isActive }) => (isActive ? "active-link" : "")}
//           >
//             Dashboard
//           </NavLink>
//         </li>
//         <li>
//           <NavLink 
//             to="/tickets" 
//             className={({ isActive }) => (isActive ? "active-link" : "")}
//           >
//             Tickets
//           </NavLink>
//         </li>
//         <li>
//           <NavLink 
//             to="/users" 
//             className={({ isActive }) => (isActive ? "active-link" : "")}
//           >
//             Users
//           </NavLink>
//         </li>
//         <li>
//           <NavLink 
//             to="/knowledge-base" 
//             className={({ isActive }) => (isActive ? "active-link" : "")}
//           >
//             Knowledge Base
//           </NavLink>
//         </li>
//         <li>
//           <NavLink 
//             to="/settings" 
//             className={({ isActive }) => (isActive ? "active-link" : "")}
//           >
//             Settings
//           </NavLink>
//         </li>
//       </ul>
//     </div>
//   );
// };
// export default Sidebar;

//not generated code
// import React from 'react';
// import { Home, Ticket, Users, BookOpen, Database, Settings } from 'lucide-react';
// import './Sidebar.css';

// const Sidebar = ({ activeItem, setActiveItem }) => {
//   const menuItems = [
//     { id: 'dashboard', icon: Home, label: 'Dashboard' },
   
//     // { id: 'tickets2', icon: Ticket, label: 'Tickets' },
//     { id: 'users', icon: Users, label: 'Users' },
//      { id: 'tickets', icon: Ticket, label: 'Tickets', active: true },
//     { id: 'knowledge', icon: BookOpen, label: 'Knowledge Base' },
//     // { id: 'base', icon: Database, label: 'Base' },
//     // { id: 'settings', icon: Settings, label: 'Settings' },
//   ];

//   return (
//     <div className="sidebar">
//       <div className="logo">
//         {/* <div className="logo-icon">
//           <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
//             <rect width="32" height="32" rx="8" fill="#b3becfff"/>
//             <path d="M12 10L20 16L12 22V10Z" fill="white"/>
//           </svg>
//         </div> */}
//         <span className="logo-text">Dashboard</span>
//       </div>
      
//       <nav className="menu">
//         {menuItems.map((item) => (
//           <button
//             key={item.id}
//             className={`menu-item ${item.active ? 'active' : ''}`}
//             onClick={() => setActiveItem(item.id)}
//           >
//             <item.icon size={20} />
//             <span>{item.label}</span>
//           </button>
//         ))}
//       </nav>
//     </div>
//   );
// };

// export default Sidebar;


//generated code
// import React from 'react';
// import './Sidebar.css';

// const Sidebar = ({ activeTab, setActiveTab }) => {
//   const menuItems = [
//     // { id: 'dashboard', icon: '☑', label: 'Dashboard' },
//     { id: 'tickets', icon: '🎫', label: 'Tickets' },
//     // { id: 'users', icon: '✉', label: 'Users' },
//     { id: 'KnowledgeBase', icon: '📋', label: 'KnowledgeBase' },
//   ];

//   return (
//     <div className="sidebar">
//       <div className="sidebar-header">
//         <div className="logo-container">
//           {/* <div className="logo-icon">⊞</div> */}
//           <span className="logo-text">Support</span>
//         </div>
//       </div>
      
//       <nav className="sidebar-nav">
//         {menuItems.map((item) => (
//           <div
//             key={item.id}
//             className={`sidebar-item ${activeTab === item.id ? 'active' : ''}`}
//             onClick={() => setActiveTab(item.id)}
//           >
//             <span className="sidebar-icon">{item.icon}</span>
//             <span className="sidebar-label">{item.label}</span>
//           </div>
//         ))}
//       </nav>
//     </div>
//   );
// };

// export default Sidebar;


import React from 'react';
import './Sidebar.css';

const Sidebar = ({ activeTab, setActiveTab }) => {
  return (
    <div className="sidebar">
      <h1 className="logo">User</h1>
      <ul>
        <li
          className={activeTab === 'tickets' ? 'active' : ''}
          onClick={() => setActiveTab('tickets')}
        >
          Tickets
        </li>
        <li
          className={activeTab === 'knowledge' ? 'active' : ''}
          onClick={() => setActiveTab('knowledge')}
        >
          Knowledge Base
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
