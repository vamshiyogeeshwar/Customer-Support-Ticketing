import React from 'react'
import './Nav.css'
import {Link } from "react-router-dom";
// import logbox from '../../assets/images/login-box-line.png'

const Nav = () => {
  return (
    <div className='navbar'>
      <h1>Support</h1>
      {/* <Link to="/Home">Support</Link> */}
{/* 
    <img src={logbox} alt=""  className='login'/> */}
    
    </div>
  )
}

export default Nav
