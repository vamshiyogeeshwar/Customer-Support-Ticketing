

import React from 'react';
import './Sidebar2.css';

const Sidebar2 = ({ activeTab, setActiveTab }) => {
  return (
    <div className="sidebar">
      <h1 className="logo">Suppport</h1>
      <ul>
        <li
          className={activeTab === 'tickets' ? 'active' : ''}
          onClick={() => setActiveTab('tickets')}
        >
          Tickets
        </li>
        <li
          className={activeTab === 'knowledge' ? 'active' : ''}
          onClick={() => setActiveTab('knowledge')}
        >
          Knowledge Base
        </li>
      </ul>
    </div>
  );
};

export default Sidebar2;
