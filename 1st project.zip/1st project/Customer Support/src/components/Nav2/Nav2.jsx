import React from 'react'
import './Nav2.css'


const Nav2 = () => {
  return (
    <div>
      <div className='navbar2'>
            <h1>Support</h1>   

            <img src="" alt="" />      
          </div>
    </div>
  )
}

export default Nav2
