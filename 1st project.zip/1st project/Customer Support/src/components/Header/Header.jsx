// import React from "react";
// import "./Topbar.css";

// const Topbar = () => {
//   return (
//     <div className="topbar">
//       <div className="top-icons">
//         <span>🔔</span>
//         <span>👤</span>
//       </div>
//     </div>
//   );
// };

// export default Topbar;


// Header Component
// import React from 'react';
// import { Bell, MessageSquare } from 'lucide-react';
// import './Header.css';

// const Header = () => {
//   return (
//     <header className="header">
//       <h1 className="page-title">System Overview</h1>
//       <div className="header-actions">
//         {/* <button className="icon-button notification">
//           <Bell size={20} />
//           <span className="badge">1</span>
//         </button> */}
//         {/* <button className="icon-button notification">
//           <MessageSquare size={20} />
//           <span className="badge">2</span>
//         </button> */}
//         <div className="user-avatar">
//           <img src="../../assets/images/user-round.png" alt="User" />
//         </div>
//       </div>
//     </header>
//   );
// };

// export default Header;


