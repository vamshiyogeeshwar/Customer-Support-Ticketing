// import React from "react";
// import "./OverviewCards.css";

// const OverviewCards = () => {
//   return (
//     <div className="cards">
//       <div className="card">
//         <h3>Current Ticket Volume</h3>
//         <p>245 Tickets</p>
//       </div>
//       <div className="card">
//         <h3>Average Resolution Time</h3>
//         <p>4.2 Hours</p>
//       </div>
//       <div className="card">
//         <h3>Open Tickets Today</h3>
//         <p>58</p>
//       </div>
//     </div>
//   );
// };

// export default OverviewCards;

import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import './MetricCard.css';

const MetricCard = ({ title, value, unit, trend, chartData, icon }) => {
  return (
    <div className="metric-card">
      <h3 className="metric-title">{title}</h3>
      <div className="metric-value-container">
        <span className="metric-value">{value}</span>
        {trend && (
          <span className={`trend ${trend.type}`}>
            {trend.type === 'up' ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
          </span>
        )}
        {unit && <span className="metric-unit">{unit}</span>}
      </div>
      <div className="metric-label">{unit === 'hours' ? 'Hours' : 'Ticks'}</div>
      {icon && (
        <div className="metric-icon">
          {icon}
        </div>
      )}
      {chartData && (
        <svg className="mini-chart" viewBox="0 0 100 30" preserveAspectRatio="none">
          <polyline
            points={chartData}
            fill="none"
            stroke={trend?.type === 'down' ? '#10B981' : '#3B82F6'}
            strokeWidth="2"
          />
        </svg>
      )}
    </div>
  );
};

export default MetricCard;