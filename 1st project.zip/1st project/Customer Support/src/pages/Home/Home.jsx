import React from "react";
import "./Home.css";
import Nav from "../../components/Nav/Nav";
import cs  from '../../assets/images/cs2.jpg' 
import { useNavigate } from "react-router-dom";

const Home = () => {

  const navigate = useNavigate();
  
  const goToLogin = () => {
    navigate("/login");
  };
  return (
    <div>
      <Nav />
      <div className="Body">
        <div className="second">
            <img src={cs} alt="" />
            
        </div>
        <div className="first">
            <h1>Welcome To Support Team</h1>
            <p>lets Collaborate each Other and Solve Our Problems</p>
            <button onClick={goToLogin}>Login</button>
            
        </div>
        
      </div>
    </div>
  );
};

export default Home;
