import "./Login.css";
import Nav from "../../components/Nav2/Nav2";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

const Login = () => {

     const [role, setRole] = useState(""); // state to track dropdown value
  const navigate = useNavigate();

  const handleLogin = () => {
    if (role === "user") {
      navigate("/user");
    } else if (role === "support") {
      navigate("/support");
    } else if (role === "/admin") {
      navigate("../Dashboard/Dashboard.jsx");}
    // } else {
    //   alert("Please select a role before logging in!");
    // }
  };


  return (
    <div>
      <Nav />
      <h1 className="head">Let's get Connected!</h1>
      <div className="Loginform">
        <h1>Login</h1>
        <form action="#" className="formm">
          <select 
          value={role}
          onChange={(e) => setRole(e.target.value)} required>
            <option >Select A Role</option>
            <option >Login As User</option>
            <option >Login As Support</option>
            <option >Login As Admin</option>
          </select>
          <input type="text" placeholder="Enter Your UserName" />
          <input type="password" placeholder="Enter Your Password" required />
        </form>

        <div className="rm">
          <input type="checkbox" />
          <label htmlFor="">Remember me</label>
          {/* <a href="">Forgot Password?</a> */}
          <Link to="/forgot">Forgot Password?</Link>
        </div>
        <button onClick={handleLogin}>Login</button>
        <div className="ca">
          <p>Don't have an Account?</p>
          {/* <a href="">Create Account</a> */}
          <Link to="/CreateAcc">Create Account</Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
