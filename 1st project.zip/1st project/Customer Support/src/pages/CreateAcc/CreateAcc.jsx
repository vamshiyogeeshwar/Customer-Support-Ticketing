import React from "react";
import "./CreateAcc.css";
import Nav from "../../components/Nav2/Nav2";
import { useNavigate } from "react-router-dom";

const CreateAcc = () => {
const navi = useNavigate();
  
  const goToLogin = () => {
    navi("/login");
  };

  return (
    <div>
      <Nav />

      <div className="CreateA">

        <h1>Create Account</h1>
        <form action="" className="Acc">
          <input type="text" placeholder="Enter Your FullName" required />
          <input type="email" placeholder="Enter Your Email" required />
          <input type="phone" placeholder="Enter Your Phone Number" required />
          <input type="text" placeholder="Enter Username" required />
          <input type="password" placeholder="Enter Your Password" required />
          <input type="password" placeholder="Re-Enter Your Password" required />
          
        </form>
        <div className="license">
          <input type="checkbox" />
          <label htmlFor="">Accept to the License and Agreement</label>
        </div>

        <button onClick={goToLogin}>Create Account</button>
      </div>
    </div>
  );
};

export default CreateAcc;
